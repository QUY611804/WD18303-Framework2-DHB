// src/routes/ClientRoutes.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';


const ClientRoutes = () => {
  return (
    <Routes>
    </Routes>
  );
};

export default ClientRoutes;
